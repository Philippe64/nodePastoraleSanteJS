"use strict";

 exports.initApplication = function (cbk){
    var oApplication = {};
    cbk(null,oApplication);
};
